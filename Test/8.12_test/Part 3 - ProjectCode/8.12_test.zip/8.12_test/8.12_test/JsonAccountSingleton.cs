using System.Text.Json;

namespace _8._12_test
{
    /// <summary>
    /// DESIGN PATTERN: SINGLETON
    /// ??m b?o t?p accounts.json ch? ???c ??c 1 l?n duy nh?t v�o b? nh?.
    /// Gi�p ti?t ki?m t�i nguy�n I/O v� ??ng b? d? li?u ng??i d�ng trong su?t v�ng ??i Server.
    /// </summary>
    internal class JsonAccountSingleton
    {
        private static JsonAccountSingleton instance = null;
        public List<User> users;

        private JsonAccountSingleton()
        {
            // Thi?t l?p c�c ???ng d?n kh? thi ?? t�m file accounts.json
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string filePath = Path.Combine(baseDir, "data", "accounts.json");
            
            // N?u kh�ng th?y trong bin, th? t�m ? project source (d�nh cho Visual Studio Debug)
            if (!File.Exists(filePath))
            {
                // ?i ng??c l�n 3 c?p t? bin/Debug/net8.0/ ?? v�o th? m?c project
                string projectDir = Path.GetFullPath(Path.Combine(baseDir, "..", "..", ".."));
                filePath = Path.Combine(projectDir, "data", "accounts.json");
            }

            // Ki?m tra v� n?p d? li?u
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                users = JsonSerializer.Deserialize<List<User>>(json) ?? new List<User>();
                Console.WriteLine($"[SUCCESS] Loaded users from: {filePath}");
                Console.WriteLine($"[INFO] Number of accounts: {users.Count}");
            }
            else
            {
                users = new List<User>();
                Console.WriteLine($"[ERROR] accounts.json NOT FOUND!");
                Console.WriteLine($"[DEBUG] Tried path: {filePath}");
            }
        }

        /// <summary>
        /// Ph??ng th?c truy c?p duy nh?t ?? l?y th?c th? (Instance) c?a l?p.
        /// </summary>
        public static JsonAccountSingleton getInstance()
        {
            if (instance == null)
            {
                instance = new JsonAccountSingleton();
            }
            return instance;
        }
    }
}