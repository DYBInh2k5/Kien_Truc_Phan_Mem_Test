namespace _8._12_test
{
    /// <summary>
    /// Qu?n l� d? li?u v� tr?ng th�i c?a m?t ph�ng chat c? th?.
    /// Bao g?m danh s�ch tin nh?n v� logic ki?m tra tr?ng th�i Online/Offline.
    /// </summary>
    class ChatRoom
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<Message> Messages { get; set; } = new List<Message>();
        public DateTime LastActivity { get; set; } = DateTime.MinValue;

        /// <summary>
        /// Logic y�u c?u: Ki?m tra ph�ng c� ho?t ??ng trong 3 ph�t g?n nh?t kh�ng.
        /// N?u kh�ng ho?t ??ng (Offline): X�a s?ch l?ch s? tin nh?n.
        /// </summary>
        public bool IsOnline()
        {
            if (DateTime.Now - LastActivity <= TimeSpan.FromMinutes(3))
            {
                return true;
            }
            // If offline, its history is cleared.
            if (Messages.Count > 0) Messages.Clear();
            return false;
        }
    }
}