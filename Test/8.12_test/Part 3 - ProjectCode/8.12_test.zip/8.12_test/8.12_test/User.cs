namespace _8._12_test
{
    /// <summary>
    /// Model ??i di?n cho ng??i d�ng (User) trong h? th?ng.
    /// D�ng ?? map d? li?u t? file JSON `accounts.json` th�ng qua th? vi?n `System.Text.Json`.
    /// Ch?a hai thu?c t�nh: `username` v� `password`.
    /// </summary>
    public class User
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}