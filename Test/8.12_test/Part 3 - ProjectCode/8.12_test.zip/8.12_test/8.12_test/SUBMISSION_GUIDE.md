SA TEST - Submission & Viva Guide

M?c ?�ch
- T�i li?u n�y m� t? chi ti?t quy ??nh n?p b�i, c?u tr�c th? m?c b?t bu?c v� k?ch b?n tr�nh b�y (m�n h�nh ch?y + code) ?? b?n chu?n b? v?n ?�p.

1) Attendance (Hi?n di?n)
- Ph?i c� m?t t?i ph�ng Lab/l?p h?c trong bu?i n?p v� v?n ?�p. V?ng kh�ng ph�p c� th? d?n t?i kh�ng ???c ch?m.

2) Submission structure (C?u tr�c n?p tr�n h? th?ng)
- B?t bu?c n?p ?�ng 3 th? m?c ? root c?a zip:
  - `Results-screenshots` : 3-5 ?nh ch?p m�n h�nh giao di?n ?ang ch?y (Home, Login success, Login fail, Chat room, Online/Offline).
  - `Code-DesignPatterns` : 3-5 ?nh ch?p ?o?n code minh h?a �p d?ng Design Patterns (Singleton, Builder).
  - `ProjectCode` : To�n b? source code project (?i k�m folder `data`, `html`, `css` n?u c�).
- Thi?u ho?c ??t sai t�n folder s? ?nh h??ng ?i?m.

3) File naming (??t t�n file b?ng ti?ng Anh ng?n g?n, r� r�ng)
- V� d?: `login_success.png`, `chat_room_online.png`, `singleton_pattern.png`, `builder_pattern.png`, `project_source.zip`.

4) Ki?m tra ch?y ?ng d?ng (Application functionality)
- B?t bu?c ch?y ???c t?i `http://localhost:8080`.
- C�c l?nh c? b?n (t? th? m?c project):
  - `dotnet build`
  - `dotnet run`
- M? Console: ki?m tra c�c log nh? `[SUCCESS] Loaded users from: ...` v� `Number of accounts: 2`.

5) K?ch b?n tr�nh b�y (M�n h�nh ch?y + M�n h�nh code)
- Tr�nh t? th?c hi?n khi tr�nh b�y:
  1. M? Console server, cho gi?ng vi�n xem log kh?i ??ng v� log load `accounts.json`.
  2. M? tr�nh duy?t: v�o `http://localhost:8080` (Home page) � n�i ng?n v? n?i dung trang.
  3. Click `Login` -> ?i?n `nntu` / `56789` -> submit. 
     - Tr�nh b�y: server t?o token v� tr? `Set-Cookie`, tr�nh duy?t redirect ??n `/chat`.
     - M? Developer Tools (Network/Storage) ?? cho gi?ng vi�n xem Header `Set-Cookie` v� Cookie `token` ?� ???c l?u.
  4. ? `/chat`: hi?n th? danh s�ch ph�ng c�ng tr?ng th�i `ONLINE`/`OFFLINE`. Gi?i th�ch: so s�nh `Now - LastActivity <= 3 ph�t` ?? x�c ??nh online.
  5. V�o 1 ph�ng (`/chat/1`): hi?n th? l?ch s? tin nh?n (time, username, message) v� khung g?i tin. Th?c hi?n g?i 1 tin nh?n -> server nh?n POST -> c?p nh?t `LastActivity` -> redirect l?i ?? hi?n th? trang c� tin nh?n m?i.
  6. Minh h?a ph�ng `OFFLINE` b?ng c�ch m� ph?ng (n�u c�ch ki?m tra ho?c s?a `LastActivity` t?m th?i) v� cho th?y l?ch s? b? x�a.

6) M�n h�nh code c?n tr�nh b�y (v� nh?ng n?i dung c?n gi?i th�ch ng?n g?n)
- `Program.cs`:
  - M� t?: Socket server, l?ng nghe c?ng 8080, Accept connection, m?i connection kh?i 1 Thread.
  - N�u c�ch parse HTTP: t�ch Header/Body b?ng `\r\n\r\n` ?? l?y Method, Path, Cookie v� Body.
- `Router.cs`:
  - M� t?: ?i?u h??ng c�c route: `/`, `/login` (GET/POST), `/chat`, `/chat/:id` (GET/POST).
  - Gi?i th�ch: c�ch x? l� Redirect (302) v� c�ch set Cookie (`Set-Cookie` header).
- `JsonAccountSingleton.cs`:
  - M� t?: Singleton ??c `data/accounts.json` m?t l?n, l?u v�o `List<User>`.
  - Gi?i th�ch l?i �ch: tr�nh ??c nhi?u l?n, d? li?u d�ng chung gi?a c�c Thread.
- `ChatBuilder.cs`:
  - M� t?: Builder t?o HTML cho trang chat (title, body, form).
  - Gi?i th�ch l?i �ch: t�ch bi?t UI v� logic, d? thay theme.
- `ChatRoom.cs`:
  - M� t?: l?u `Messages`, `LastActivity` v� h�m `IsOnline()` ki?m tra 3 ph�t v� x�a l?ch s? khi offline.
- `User.cs`, `Message.cs`:
  - Model ??n gi?n cho d? li?u.

7) C�c c�u h?i hay g?p (v� c�u tr? l?i m?u ng?n g?n)
- Q: "Cookie token ???c t?o ? ?�u?" 
  - A: T?o trong `HandleLogin` (Guid.NewGuid()) v� tr? header `Set-Cookie`.
- Q: "L�m sao server bi?t user ?� ??ng nh?p?" 
  - A: D?a v�o header `Cookie` g?i k�m; code ki?m tra s? t?n t?i `token=` (??n gi?n cho b�i lab).
- Q: "L�m th? n�o ?? x�c ??nh ph�ng online?" 
  - A: So s�nh `DateTime.Now - LastActivity <= TimeSpan.FromMinutes(3)`; n?u l?n h?n th� g?i `Messages.Clear()`.
- Q: "Ph?n parse HTTP c� an to�n/ho�n ch?nh kh�ng?" 
  - A: ?�y l� b?n mini-server ph?c v? h?c t?p: parse th? c�ng ?? cho GET/POST form urlencoded; production c?n th? vi?n chu?n.
- Q: "Singleton thread-safe kh�ng?" 
  - A: Hi?n implementation l� simple Singleton. V� ch? ??c JSON m?t l?n l�c kh?i t?o, trong ng? c?nh lab n�y l� ??; n?u c?n thread-safe c� th? d�ng lock ho?c Lazy<T>.

8) Academic Integrity (Li�m ch�nh h?c thu?t)
- Kh�ng n?p code gi?ng ng??i kh�c. N?u b�i gi?ng ho?c l� s?n ph?m AI m� kh�ng hi?u, c� th? b? 0 ?i?m.

9) Checklist tr??c khi n?p
- [ ] Build th�nh c�ng (`dotnet build`).
- [ ] Server ch?y, truy c?p `http://localhost:8080` ???c.
- [ ] Ch?p ?nh m�n h�nh theo y�u c?u v� ??t t�n ?�ng.
- [ ] Ch?p ?nh code (Singleton, Builder) v�o `Code-DesignPatterns`.
- [ ] ?�ng g�i `ProjectCode` c�ng `data` folder.

10) Ghi ch� k? thu?t ng?n (debug nhanh n?u kh�ng login)
- M? Console server, ki?m tra log "[SUCCESS] Loaded users" ho?c l?i file JSON.
- N?u log b�o `accounts.json NOT FOUND`, ??m b?o file `data/accounts.json` c� trong th? m?c build (project csproj ?� c?u h�nh copy).
- Ki?m tra g?i form: developer tools -> Network -> ch?n request POST `/login` -> ki?m tra Request Payload v� Response headers (Set-Cookie).


File n�y ?� ???c t?o ?? in ho?c d�n v�o ph?n n?p b�i l�m t�i li?u k�m theo. Ch�c b?n v?n ?�p t?t v� n?p b�i th�nh c�ng.