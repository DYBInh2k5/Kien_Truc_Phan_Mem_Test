using System.Net.Sockets;
using System.Text;
using System.Web;

namespace _8._12_test
{
    /// <summary>
    /// ?�ng vai tr� l� b? ??nh tuy?n (Router) ch�nh c?a Web Server.
    /// Quy?t ??nh n?i dung HTML tr? v? d?a tr�n HTTP Method (GET/POST) v� URL Path.
    /// Qu?n l� danh s�ch ph�ng chat v� x? l� logic x�c th?c ng??i d�ng.
    /// </summary>
    class Router
    {
        private static List<ChatRoom> rooms = new List<ChatRoom>
        {
            new ChatRoom { Id = 1, Name = "General Chat" },
            new ChatRoom { Id = 2, Name = "Tech Talk" }
        };

        /// <summary>
        /// H�m x? l� ch�nh: ph�n t�ch Method v� Path r?i g?i h�m x? l� t??ng ?ng.
        /// Tham s?:
        /// - staff: Socket c?p?a client hi?n t?i
        /// - method: HTTP method (GET/POST)
        /// - path: ???ng d?n y�u c?u
        /// - body: n?i dung body (n?u c�)
        /// - cookie: header Cookie (n?u c�)
        /// </summary>
        public static void Handle(Socket staff, string method, string path, string body, string cookie)
        {
            if (method == "GET" && path == "/")
            {
                SendResponse(staff, GetHomeHtml());
            }
            else if (method == "GET" && path == "/login")
            {
                SendResponse(staff, GetLoginHtml());
            }
            else if (method == "POST" && path == "/login")
            {
                HandleLogin(staff, body);
            }
            else if (method == "GET" && path == "/chat")
            {
                SendResponse(staff, GetChatRoomsHtml());
            }
            else if (method == "GET" && path.StartsWith("/chat/"))
            {
                HandleGetChatRoom(staff, path);
            }
            else if (method == "POST" && path.StartsWith("/chat/"))
            {
                HandlePostChatRoom(staff, path, body, cookie);
            }
            else
            {
                SendResponse(staff, "<h1>404 Not Found</h1>", "404 Not Found");
            }
        }

        // Trang Home hi?n th? th�ng tin sinh vi�n v� li�n k?t t?i trang Login
        private static string GetHomeHtml()
        {
            return @"
            <html>
            <head>
                <meta charset='UTF-8'>
                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                <style>
                    :root { --primary: #f39c12; --bg: #121212; --surface: #1e1e1e; --text: #e0e0e0; }
                    body { font-family: 'Segoe UI', Arial; background: var(--bg); color: var(--text); padding: 20px; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
                    .card { background: var(--surface); padding: 40px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); width: 100%; max-width: 400px; text-align: center; }
                    h1 { color: var(--primary); margin-bottom: 25px; }
                    .info-box { text-align: left; background: #252525; padding: 20px; border-radius: 8px; margin-bottom: 25px; border-left: 4px solid var(--primary); }
                    p { margin: 10px 0; font-size: 1.1em; }
                    .btn { display: inline-block; background: var(--primary); color: black; padding: 12px 30px; border-radius: 6px; text-decoration: none; font-weight: bold; transition: 0.3s; }
                    .btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(243, 156, 18, 0.3); }
                </style>
            </head>
            <body>
                <div class='card'>
                    <h1>Student Information</h1>
                    <div class='info-box'>
                        <p><strong>Student ID:</strong> 22301500</p>
                        <p><strong>Full Name:</strong> V� Duy B�nh</p>
                        <p><strong>PC Number:</strong> PC01</p>
                    </div>
                    <a href='/login' class='btn'>Login to Chat</a>
                </div>
            </body>
            </html>";
        }

        // Trang Login (GET) - tr? form ??ng nh?p
        private static string GetLoginHtml(string message = "")
        {
            string errorStyle = string.IsNullOrEmpty(message) ? "display:none" : "display:block";
            return $@"
            <html>
            <head>
                <meta charset='UTF-8'>
                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                <style>
                    :root {{ --primary: #f39c12; --bg: #121212; --surface: #1e1e1e; --text: #e0e0e0; }}
                    body {{ font-family: 'Segoe UI', Arial; background: var(--bg); color: var(--text); padding: 20px; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }}
                    .card {{ background: var(--surface); padding: 40px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); width: 100%; max-width: 350px; }}
                    h1 {{ color: var(--primary); text-align: center; margin-bottom: 30px; }}
                    .error {{ background: #c0392b; color: white; padding: 10px; border-radius: 6px; margin-bottom: 20px; text-align: center; font-size: 0.9em; {errorStyle} }}
                    .form-group {{ margin-bottom: 20px; }}
                    label {{ display: block; margin-bottom: 8px; font-weight: bold; }}
                    input {{ width: 100%; padding: 12px; background: #333; border: 1px solid #444; border-radius: 6px; color: white; box-sizing: border-box; }}
                    input:focus {{ border-color: var(--primary); outline: none; }}
                    button {{ width: 100%; padding: 12px; background: var(--primary); border: none; border-radius: 6px; color: black; font-weight: bold; cursor: pointer; transition: 0.3s; margin-top: 10px; }}
                    button:hover {{ opacity: 0.9; transform: scale(1.02); }}
                    .back {{ display: block; text-align: center; margin-top: 20px; color: var(--primary); text-decoration: none; font-size: 0.9em; }}
                </style>
            </head>
            <body>
                <div class='card'>
                    <h1>Chat System</h1>
                    <div class='error'>{message}</div>
                    <form method='POST' action='/login'>
                        <div class='form-group'>
                            <label>Username</label>
                            <input name='username' placeholder='Enter username...' required autofocus>
                        </div>
                        <div class='form-group'>
                            <label>Password</label>
                            <input name='password' type='password' placeholder='Enter password...' required>
                        </div>
                        <button type='submit'>Login</button>
                    </form>
                    <a href='/' class='back'>Back to Home</a>
                </div>
            </body>
            </html>";
        }

        /// <summary>
        /// X? l� POST /login
        /// - Parse body (form urlencoded) -> ki?m tra username/password so v?i danh s�ch users
        /// - N?u x�c th?c th�nh c�ng: t?o token, tr? header Set-Cookie v� redirect v? /chat
        /// - N?u th?t b?i: tr? l?i trang login k�m th�ng b�o l?i
        /// </summary>
        private static void HandleLogin(Socket staff, string body)
        {
            var data = ParseQueryString(body);
            string user = data.ContainsKey("username") ? data["username"] : "";
            string pass = data.ContainsKey("password") ? data["password"] : "";

            var users = JsonAccountSingleton.getInstance().users;
            var authenticatedUser = users.Find(u => u.username == user && u.password == pass);

            if (authenticatedUser != null)
            {
                // Th�nh c�ng: t?o token v� redirect v? /chat, k�m Set-Cookie
                string token = Guid.NewGuid().ToString();
                SendRedirect(staff, "/chat", $"token={token}; Path=/; HttpOnly; Max-Age=3600");
            }
            else
            {
                SendResponse(staff, GetLoginHtml("Login failed. Please try again."));
            }
        }

        // Trang danh s�ch ph�ng chat (/chat)
        private static string GetChatRoomsHtml()
        {
            var builder = new ChatBuilder();
            builder.setTitle("Chat Rooms");
            string bodyHtml = "<ul class='room-list'>"; // danh s�ch ph�ng
            foreach (var room in rooms)
            {
                bool isOnline = room.IsOnline();
                string status = isOnline ? "<span class='online'>ONLINE</span>" : "<span class='offline'>OFFLINE</span>";
                bodyHtml += $"<li class='room-item'><a href='/chat/{room.Id}'>{room.Name}</a> - {status}</li>";
            }
            bodyHtml += "</ul>";
            return builder.setBody(bodyHtml).build();
        }

        /// <summary>
        /// X? l� GET /chat/{id}
        /// - L?y ph�ng theo id, hi?n th? l?ch s? tin nh?n (theo th? t? th?i gian) v� form g?i tin
        /// - N?u ph�ng offline th� l?ch s? ?� b? x�a b?i ChatRoom.IsOnline()
        /// </summary>
        private static void HandleGetChatRoom(Socket staff, string path)
        {
            if (!int.TryParse(path.Replace("/chat/", ""), out int roomId))
            {
                SendResponse(staff, "<h1>Invalid Room ID</h1>", "400 Bad Request");
                return;
            }

            var room = rooms.Find(r => r.Id == roomId);
            if (room != null)
            {
                room.IsOnline(); // C?p nh?t tr?ng th�i
                var builder = new ChatBuilder();
                builder.setTitle(room.Name);
                
                // S? d?ng addMessage c?a Builder thay v� c?ng chu?i th? c�ng
                foreach (var msg in room.Messages)
                {
                    builder.addMessage(msg);
                }
                
                // S? d?ng addInputForm c?a Builder
                builder.addInputForm(room.Id);

                SendResponse(staff, builder.build());
            }
            else
            {
                SendResponse(staff, "<h1>Room not found</h1>", "404 Not Found");
            }
        }

        /// <summary>
        /// X? l� POST /chat/{id}
        /// - L?y n?i dung message t? body, decode v� th�m v�o danh s�ch tin nh?n c?a ph�ng
        /// - C?p nh?t LastActivity ?? ph�ng ???c ?�nh d?u online
        /// - Redirect v? GET /chat/{id} ?? hi?n th? l?i trang
        /// </summary>
        private static void HandlePostChatRoom(Socket staff, string path, string body, string cookie)
        {
            if (!int.TryParse(path.Replace("/chat/", ""), out int roomId))
            {
                SendRedirect(staff, "/chat");
                return;
            }

            var room = rooms.Find(r => r.Id == roomId);
            var data = ParseQueryString(body);
            string messageContent = data.ContainsKey("message") ? data["message"] : "";

            if (room != null && !string.IsNullOrEmpty(messageContent))
            {
                // Simple session check via cookie
                string user = "Guest";
                if (!string.IsNullOrEmpty(cookie) && cookie.Contains("token="))
                {
                    // In a real app we'd map token to username. Here we just show authenticated status.
                    user = "Member";
                }

                room.Messages.Add(new Message
                {
                    Username = user,
                    Content = HttpUtility.UrlDecode(messageContent),
                    Timestamp = DateTime.Now
                });
                room.LastActivity = DateTime.Now;
                SendRedirect(staff, $"/chat/{roomId}");
            }
            else
            {
                SendRedirect(staff, $"/chat/{roomId}");
            }
        }

        /// <summary>
        /// G?i ph?n h?i HTTP chu?n v? Browser bao g?m: Status line, Headers v� Body.
        /// N?u c� cookie, th�m header Set-Cookie.
        /// </summary>
        private static void SendResponse(Socket staff, string body, string status = "200 OK", string cookie = null)
        {
            byte[] bodyBytes = Encoding.UTF8.GetBytes(body);

            StringBuilder sb = new StringBuilder();
            sb.Append($"HTTP/1.1 {status}\r\n");
            sb.Append("Content-Type: text/html; charset=UTF-8\r\n");
            sb.Append($"Content-Length: {bodyBytes.Length}\r\n");
            if (!string.IsNullOrEmpty(cookie)) sb.Append($"Set-Cookie: {cookie}; Path=/; HttpOnly\r\n");
            sb.Append("Connection: close\r\n");
            sb.Append("\r\n");

            byte[] headerBytes = Encoding.UTF8.GetBytes(sb.ToString());
            
            byte[] fullResponse = new byte[headerBytes.Length + bodyBytes.Length];
            Buffer.BlockCopy(headerBytes, 0, fullResponse, 0, headerBytes.Length);
            Buffer.BlockCopy(bodyBytes, 0, fullResponse, headerBytes.Length, bodyBytes.Length);

            staff.Send(fullResponse);
            staff.Close();
        }

        /// <summary>
        /// G?i header 302 Found ?? tr�nh duy?t t? ??ng chuy?n h??ng.
        /// N?u c� cookie, th�m header Set-Cookie.
        /// </summary>
        private static void SendRedirect(Socket staff, string location, string cookie = null)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("HTTP/1.1 302 Found\r\n");
            sb.Append($"Location: {location}\r\n");
            if (!string.IsNullOrEmpty(cookie)) sb.Append($"Set-Cookie: {cookie}; Path=/; HttpOnly\r\n");
            sb.Append("Connection: close\r\n\r\n");

            staff.Send(Encoding.UTF8.GetBytes(sb.ToString()));
            staff.Close();
        }

        /// <summary>
        /// Parse chu?i query string d?ng key1=val1&key2=val2 th�nh Dictionary.
        /// Gi� tr? ???c URL-decode.
        /// </summary>
        private static Dictionary<string, string> ParseQueryString(string query)
        {
            var dict = new Dictionary<string, string>();
            foreach (var part in query.Split('&'))
            {
                var kv = part.Split('=');
                if (kv.Length == 2) dict[kv[0]] = HttpUtility.UrlDecode(kv[1]);
            }
            return dict;
        }
    }
}